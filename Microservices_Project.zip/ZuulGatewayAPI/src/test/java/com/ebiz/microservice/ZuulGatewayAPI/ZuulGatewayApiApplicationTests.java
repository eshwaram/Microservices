package com.ebiz.microservice.ZuulGatewayAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulGatewayApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
