package com.ebiz.microservice.product.ProductInfoSVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductInfoSvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
