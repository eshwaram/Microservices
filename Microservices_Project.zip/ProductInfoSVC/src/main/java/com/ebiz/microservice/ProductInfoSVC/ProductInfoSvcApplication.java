package com.ebiz.microservice.ProductInfoSVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ProductInfoSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductInfoSvcApplication.class, args);
	}

}
