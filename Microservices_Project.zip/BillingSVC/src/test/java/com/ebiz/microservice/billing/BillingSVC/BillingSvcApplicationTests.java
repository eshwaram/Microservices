package com.ebiz.microservice.billing.BillingSVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingSvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
