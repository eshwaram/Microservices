package com.ebiz.microservice.billing.BillingSVC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BillingSvcController {

	@Autowired
	private ProductInfoSVCProxy proxy;

	@GetMapping("/getBill/{prodName}/{quantity}")
	public BillEntity calculateBill(@PathVariable String prodName, @PathVariable int quantity) {
		ProductEntity prodInfo = proxy.getProductInfo(prodName);
		BillEntity bill = new BillEntity();
		bill.setProduct(prodInfo.getName());
		bill.setPrice(prodInfo.getPrice());
		bill.setQuantity(quantity);
		bill.setBillAmount(quantity * prodInfo.getPrice());
		bill.setProductSVCInstance(prodInfo.getPort());
		return bill;
	}

}
