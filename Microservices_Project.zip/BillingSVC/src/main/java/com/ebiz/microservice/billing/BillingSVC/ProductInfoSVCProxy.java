package com.ebiz.microservice.billing.BillingSVC;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(name="ProductInfoSVC", url="localhost:8001")
//@FeignClient(name="ProductInfoSVC")
@FeignClient(name="ZuulGatewayAPI")
@RibbonClient(name="ProductInfoSVC")
public interface ProductInfoSVCProxy {

	@GetMapping("/productInfo/getProductInfo/{prodName}")
	//@GetMapping("/productInfo/getProductInfo/{prodName}")
	public ProductEntity getProductInfo(@PathVariable String prodName);
	
}
