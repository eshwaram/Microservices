package com.ebiz.microservice.billing.BillingSVC;

public class BillEntity {

	private String product;
	private int price;
	private int quantity;
	private int billAmount;
	private String productSVCInstance;

	public BillEntity() {
	}

	public BillEntity(String product, int price, int quantity, int billAmount) {
		this.product = product;
		this.price = price;
		this.quantity = quantity;
		this.billAmount = billAmount;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}

	public String getProductSVCInstance() {
		return productSVCInstance;
	}

	public void setProductSVCInstance(String port) {
		this.productSVCInstance = port;
	}

}
