package com.ebiz.microservice.billing.BillingSVC;

public class ProductEntity {

	private String name;
	private int price;
	private String port;

	public ProductEntity() {

	}

	public ProductEntity(String name, int price) {
		this.name = name;
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

}
